#! /usr/bin/bash
# display list of files in the current directory

figlet "Z.M Tarek Sahariar"
pwd
ls -l