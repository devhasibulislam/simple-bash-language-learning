#! /usr/bin/bash
# celsius to kalvin
echo -n "enter temp. in celsius: "
read c
k=$((c+273))
echo $k kalvin